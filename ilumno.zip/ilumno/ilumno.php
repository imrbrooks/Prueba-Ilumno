<?php
/*
Plugin Name: Ilumno Form Prueba
Description: Plugin creado para desarrollar la prueba de Webmaster para Ilumno 
Author: Daniel Jiménez
Version: 1.0
*/

//Crear DataBase Table
// Crea la DB al activar el plugin
register_activation_hook(__FILE__, 'FormularioEduCont_init');
 
/*
 * Crea la tabla para recoger los datos del formulario
 *
 * @return void
 */
function FormularioEduCont_init() 
{
    global $wpdb; // Este objeto global permite acceder a la base de datos de WP
    // Crea la tabla sólo si no existe
    // Utiliza el mismo prefijo del resto de tablas
    $tabla_continuada = $wpdb->prefix . 'educont';
    // Utiliza el mismo tipo de orden de la base de datos
    $charset_collate = $wpdb->get_charset_collate();
    // Prepara la consulta
    $query = "CREATE TABLE IF NOT EXISTS $tabla_continuada (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        tipoPrograma varchar(50) NOT NULL,
        sedes varchar(50) NOT NULL,
        programa varchar(50) NOT NULL,
        nombre varchar(50) NOT NULL,
        apellido varchar(50) NOT NULL,
        tipoID varchar(50) NOT NULL,
        documento varchar(20) NOT NULL,
        correo varchar(100) NOT NULL,
        celular varchar(20) NOT NULL,
        departamento varchar(50) NOT NULL,
        inputCiudad varchar(50) NOT NULL,
        terminos smallint(4) NOT NULL,
        created_at datetime NOT NULL,
        UNIQUE (id)
        ) $charset_collate;";
    // La función dbDelta permite crear tablas de manera segura se
    // define en el archivo upgrade.php que se incluye a continuación
    include_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($query); // Lanza la consulta para crear la tabla de manera segura
}
//End of Crear DataBase Table
 
// Define el shortcode y lo asocia a una función
add_shortcode('form_educont', 'Form_Educont');
 
/*
* @return string
*/

function Form_Educont()
{
    //Comprueba envío de datos y pinta formulario
    global $wpdb; // Este objeto global permite acceder a la base de datos de WP
    
    if(!empty($_POST)
    AND $_POST['tipoPrograma'] != ''
    AND $_POST['sedes'] != ''
    AND $_POST['programa'] != ''
    AND $_POST['nombre'] != ''
    AND $_POST['apellido'] != ''
    AND $_POST['tipoID'] != ''
    AND $_POST['documento'] != ''
    AND is_email($_POST['correo'])
    AND $_POST['celular'] != ''
    AND $_POST['departamento'] != ''
    AND $_POST['inputCiudad'] != ''
    AND $_POST['terminos'] == '1'
    ) {
        $tabla_continuada = $wpdb->prefix . 'educont';
        $tipoPrograma = sanitize_text_field($_POST['tipoPrograma']);
        $sedes = sanitize_text_field($_POST['sedes']);
        $programa = sanitize_text_field($_POST['programa']);
        $nombre = sanitize_text_field($_POST['nombre']);
        $apellido = sanitize_text_field($_POST['apellido']);
        $tipoID = sanitize_text_field($_POST['tipoID']);
        $documento = sanitize_text_field($_POST['documento']);
        $correo = sanitize_email($_POST['correo']);
        $celular = sanitize_text_field($_POST['celular']);
        $departamento = sanitize_text_field($_POST['departamento']);
        $inputCiudad = sanitize_text_field($_POST['inputCiudad']);
        $terminos = (int)$_POST['terminos'];
        $created_at = date('Y-m-d H:i:s');
        $wpdb->insert(
            $tabla_continuada,
            array(
                'tipoPrograma' => $tipoPrograma,
                'sedes' => $sedes,
                'programa' => $programa,
                'nombre' => $nombre,
                'apellido' => $apellido,
                'tipoID' => $tipoID,
                'documento' => $documento,
                'correo' => $correo,
                'celular' => $celular,
                'departamento' => $departamento,
                'inputCiudad' => $inputCiudad,
                'terminos' => $terminos
            )
        );
    }

    // Cargar hoja de estilo y scripts
    wp_enqueue_style('css_formulario', plugins_url('css/style.css', __FILE__));
    wp_enqueue_script('scripts', plugins_url('js/ciudades.js', __FILE__));
    wp_enqueue_script('mensaje', plugins_url('js/mensaje.js', __FILE__));
    ob_start();
?>

<div class="container formulario">
<form action="<?php get_the_permalink();?>" method="post" id="form_continuada" class="cuestionario">
<?php wp_nonce_field('graba_continuada', 'continuada_nonce');?>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputTipoPrograma">Tipo de programa</label>
            <select name="tipoPrograma" id="inputTipoPrograma" class="form-control input-lg" required >
                <option value="" disabled selected>Tipo de programa</option>
                <option>Pregrado</option>
                <option>Posgrado</option>
            </select>
            <i class="fa fa-chevron-down"></i>
        </div>
        <div class="form-group col-md-6">
            <label for="inputSedes">Sedes</label>
            <select name="sedes" id="inputSedes" class="form-control input-lg" required>
                <option value="" disabled selected>Sedes</option>
                <option>Bucaramanga</option>
                <option>Bogotá</option>
            </select>
            <i class="fa fa-chevron-down"></i>
        </div>
    </div>
    <div class="form-group">
        <label for="inputPrograma">Programa</label>
        <select name="programa" id="inputPrograma" class="form-control input-lg">
            <option value="" disabled selected>Programa</option>
            <option>Opción 1</option>
            <option>Opción 2</option>
            <option>Opción 3</option>
        </select>
        <i class="fa fa-chevron-down"></i>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputNombre">Nombre</label>
            <input type="text" name="nombre" class="form-control" placeholder="Nombre" required maxlength="50">
        </div>
        <div class="form-group col-md-6">
            <label for="inputApellido">Apellido</label>
            <input type="text" name="apellido" class="form-control" placeholder="Apellido" required maxlength="50">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputTipoID">Tipo de documento</label>
            <select name="tipoID" id="inputTipoID" class="form-control input-lg" required>
                <option value="" disabled selected>Tipo de documento</option>
                <option>Cédula de Ciudadanía</option>
                <option>Cédula de Extranjería</option>
            </select>
            <i class="fa fa-chevron-down"></i>
        </div>
        <div class="form-group col-md-6">
            <label for="inputID">Documento</label>
            <input type="text" name="documento" class="form-control" placeholder="Documento" pattern="[0-9]+" required maxlength="12">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Correo Electrónico</label>
            <input type="email" name="correo" class="form-control" id="inputEmail4" placeholder="Correo Electrónico" />
        </div>
        <div class="form-group col-md-6">
            <label for="inputCelular">Celular</label>
            <input type="text" name="celular" class="form-control" placeholder="Celular" pattern="[0-9]+" required maxlength="12">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputDepartamento">Departamento</label>
            <select name="departamento" id="inputDepartamento" class="form-control input-lg" required >
                <option value="0" disabled selected>Departamento</option>
                <option value="Antioquia">Antioquia</option>
                <option value="Cundinamarca">Cundinamarca</option>
                <option value="Santander">Santander</option>
            </select>
            <i class="fa fa-chevron-down"></i>
        </div>
        <div class="form-group col-md-6">
            <label for="inputCiudad">Ciudad</label>
            <select name="inputCiudad" id="inputCiudad" class="form-control input-lg" required>
                <option value="0" disabled selected>Ciudad</option>
            </select>
            <i class="fa fa-chevron-down"></i>
        </div>
    </div>
    <div class="form-check">
        <input class="form-check-input" name="terminos" type="radio" id="terminos" value="1">
        <label class="form-check-label" for="terminos">
            Acepto los términos de uso
        </label>
    </div>
    <div class="form-group">
        <input class="enviarForm" type="submit" value="Enviar">
    </div>
    <div id="alerta" class="alert d-none">
        <button type="button" class="close" data-dismmiss="alert" aria-hidden="true">&times;</button>
        <strong class="respuesta"></strong> <span class="mensaje-alerta"></span>
    </div>
</form>
</div>

    <?php
    return ob_get_clean();
}

add_action("admin_menu", "EduContinuada_menu");

function Educontinuada_menu()
{
    add_menu_page("Formulario Prueba" , "Prueba Ilumno" , "manage_options" , "educont_menu" , "eduContinuada_admin" , "dashicons-feedback", 75);
}

function eduContinuada_admin()
{
    global $wpdb;
    $tabla_continuada = $wpdb->prefix . 'educont';
    $inscritos = $wpdb->get_results("SELECT * FROM $tabla_continuada");
    echo '<div class="wrap"><h1>Lista de Inscritos</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th width="5%">Tipo Prog.</th><th width="5%">Sede</th><th width="10%">Programa</th><th width="10%">Nombre</th><th width="10%">Apellido</th><th width="5%">Tipo Doc</th><th width="5%">Documento</th><th width="10%">Email</th><th width="5%">Celular</th><th width="5%">Depto.</th><th width="5%">Ciudad</th><th width="5%">Términos</th>';
    echo '</tr></thead>';
    echo '<tbody id="the_list">';
    foreach ($inscritos as $inscrito){
        $tipoPrograma = esc_textarea($inscrito->tipoPrograma);
        $sedes = esc_textarea($inscrito->sedes);
        $programa = esc_textarea($inscrito->programa);
        $nombre = esc_textarea($inscrito->nombre);
        $apellido = esc_textarea($inscrito->apellido);
        $tipoID = esc_textarea($inscrito->tipoID);
        $documento = esc_textarea($inscrito->documento);
        $correo = esc_textarea($inscrito->correo);
        $celular = esc_textarea($inscrito->celular);
        $departamento = esc_textarea($inscrito->departamento);
        $inputCiudad = esc_textarea($inscrito->inputCiudad);
        $terminos = (int) $inscrito->terminos;
        echo "<tr><td>$tipoPrograma</td><td>$sedes</td><td>$programa</td><td>$nombre</td><td>$apellido</td><td>$tipoID</td><td>$documento</td><td>$correo</td><td>$celular</td><td>$departamento</td><td>$inputCiudad</td><td>$terminos</td></tr>";
    }
    echo '</tbody></table></div>';
}