jQuery(document).ready( $ => {

    $("#form_continuada").bind("submit", function() {
        $.ajax({
            type: $(this).attr("method"),
            url: $(this).attr("action"),
            data: $(this).serialize(),
            success: function() {
                $("#alerta").removeClass("d-none").addClass("alert-success");
                $(".respuesta").html("¡Enviado!")
                $(".mensaje-alerta").html("Tus datos fueron enviados satisfactoriamente.")
            },
            error: function() {
                $("#alerta").removeClass("d-none").addClass("alert-danger");
                $(".respuesta").html("¡Error!")
                $(".mensaje-alerta").html("Debes revisar los campos diligenciados en el formulario.")
            }
        });
        return false;
    })

});