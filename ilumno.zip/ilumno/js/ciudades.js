jQuery(document).ready( $ => {
 
    $("#inputDepartamento").on('change', function () {
        $("#inputDepartamento option:selected").each(function () {
            depto=$(this).val();
            $.post("wp-content/plugins/ilumno/ciudades.php", { depto: depto }, function(data){
                $("#inputCiudad").html(data);
            });			
        });
   });
   if (window.history.replaceState) { // verificamos disponibilidad
    window.history.replaceState(null, null, window.location.href);
   }
});