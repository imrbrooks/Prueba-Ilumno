

<?php
$html = "";
if ($_POST["depto"]==Antioquia) {
	$html = '
	<option value="Apartado">Apartado</option>
	<option value="Bello">Bello</option>
	<option value="El peñol">El peñol</option>
	<option value="Itagui">Itagui</option>
	<option value="Medellín">Medellín</option>
	<option value="Rionegro">Rionegro</option>
	';	
}
if ($_POST["depto"]==Cundinamarca) {
	$html = '
	<option value="Agua de dios">Agua de dios</option>
	<option value="Alban">Alban</option>
	<option value="Anapoima">Anapoima</option>
	<option value="Anolaima">Anolaima</option>
	<option value="Bogotá D.C">Bogotá D.C</option>
	<option value="Cajicá">Cajicá</option>
	<option value="Chía">Chía</option>
	<option value="Fusagasuga">Fusagasuga</option>
	<option value="Soacha">Soacha</option>
	<option value="Zipaquirá">Zipaquirá</option>
	';	
}
if ($_POST["depto"]==Santander) {
	$html = '
	<option value="Barichara">Barichara</option>
	<option value="Barbosa">Barbosa</option>
	<option value="Barrancabermeja">Barrancabermeja</option>
	<option value="Bucaramanga">Bucaramanga</option>
	<option value="San Gil">San Gil</option>
	<option value="Zapatoca">Zapatoca</option>
	';	
}
echo $html;	
?>